module.exports = {
  plugins: {
    tailwindcss: {}
  }
}
