Upgrade the Inertia adapter in the repo to match the current Inertia v3 protocol contract. The task is scoped to the adapter package and should not change unrelated application code or templates.

Required behavior:

- Page metadata should include only the enabled history and fragment flags. When `clearHistory`, `encryptHistory`, or `preserveFragment` are enabled, the page object should expose them as `true`; otherwise those fields should be omitted.
- The page object should expose shared-prop metadata under the public `sharedProps` key, and the shared keys should remain available in the resolved props while preserving the expected override semantics.
- Request-scoped fragment preservation should be honored for the active request and not leak across requests. The public contract includes the fragment-preservation flag and the associated session key used by the adapter.
- Deferred props should support rescue semantics so that a failed deferred callback can be omitted from the page props and reported via the corresponding rescued-props metadata instead of crashing the full response.
- Merge and scroll metadata must use the v3 protocol shape. The adapter should emit the correct merge/prepend/deep-merge metadata and match keys only for the props that are actually available, and should suppress that metadata on reset requests.
- Scroll metadata should report the current page state and paging boundaries in the expected client-facing shape.
- Asset-version mismatches should trigger the expected GET-only conflict flow with the correct Inertia headers and location. Non-GET mismatches should continue through the normal render path.
- Inertia JSON responses should include the expected response and `Vary` headers and return the resolved props under the standard `props` field.

Public contract names that matter for compatibility:

- `sharedProps`
- `clearHistory`, `encryptHistory`, `preserveFragment`
- `rescuedProps`
- `_inertiaPreserveFragment`
- `mergeProps`, `prependProps`, `deepMergeProps`, `matchPropsOn`
- `scrollProps`
- `X-Inertia`
- `X-Inertia-Location`
- `X-Inertia-Version`
- `X-Inertia-Infinite-Scroll-Merge-Intent`
- `X-Inertia-Reset`

Do not modify any test files. Keep the change focused on the adapter contract and observable behavior that the Inertia client expects.
